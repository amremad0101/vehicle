public interface Payable {
    boolean processPayment(double amount);
}
