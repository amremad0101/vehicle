
public class Admin extends User {

    public Admin(String username, String password, String phone) {
        super(username, password, phone);
    }

    public void addCustomer(RentalSystem system, Customer newCustomer) {
        boolean added = system.addCustomer(newCustomer);

        if (!added) {
            System.out.println("Customer already exists!");
        } else {
            System.out.println("Customer added successfully!");
        }
    }
     public void deleteCustomer(RentalSystem system,Customer newCustomer) {
        boolean result = system.deleteCustomer( newCustomer);

        if (!result) {
            System.out.println("Delete failed.");
        } else{
            System.out.println("Customer deleted ");
        }
    }
}
