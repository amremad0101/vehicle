import java.util.*;

public class RentalSystem {
    private List<Customer> customers = new ArrayList<>();

    public boolean addCustomer(Customer newCustomer) {
        for (Customer c : customers) {
            if (c.getphone().equals(newCustomer.getphone())) {
                System.out.println("Customer already exists!");
                return false;
            }
        }
        customers.add(newCustomer);
        return true;
    }
    public boolean deleteCustomer(Customer newCustomer) {

        for (Customer c : customers) {
            if (c.getphone().equals(newCustomer.getphone())) {
                customers.remove(c);
                System.out.println("Customer removed successfully.");
                return true;
            }
        }

        System.out.println("Customer NOT found.");
        return false;
    }
}
