public class CashPayment implements Payable {
    public CashPayment(){
        
    }
    @Override
    public boolean processPayment(double amount) {
        System.out.println("Payment of " + amount + "$ received in Cash.");
        return true;
    }
}