public abstract class User {
 protected String username;
 protected String password;
 protected String phone;
 
 public User(String name,String pass, String phone){
    this.username=name;
    this.password=pass;
    this.phone=phone;
 }

}
