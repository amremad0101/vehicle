public class Car extends Vehicle {
    private int seats;
    private String transmissionType; // automatic / manual
    private int horsepower;
    private String carClass;// Economy, Standard, Luxury, Sports
    
    public Car(String id, String brand, String model, double pricePerDay,
               String fuelType, double discount,
               int seats, String transmissionType,int horsepower,String carClass) {
        //Call parent constructor
        super(id,brand,model,pricePerDay,fuelType,discount);
        
        this.seats = seats;
        this.transmissionType = transmissionType;
        this.horsepower=horsepower;
        this.carClass=carClass;
    }

    public int getSeats() { return seats;}

    public String getTransmissionType() { return transmissionType;}
   
    public int getHorsepower() {return horsepower;}
      
    public String getCarClass() {return carClass;}
     
    public double getClassMultiplier() {
    return switch (carClass) {
        case "Luxury" -> 1.4;
        case "Sports" -> 1.6;
        case "Economy" -> 1.0;
        default -> 1.2; // Standard
    };
}
    @Override
public double calculateCost(int days) {
    return getDiscountedPrice() * days * getClassMultiplier();
}


@Override
public String toString() {
    return "Car: " + super.toString() +
            " | Seats: " + seats +
            " | Transmission: " + transmissionType +
            " | Horsepower: " + horsepower +
            " | Class: " + carClass;
}



     public static Car addCar(String id, String brand, String model,
                             double price, String fuelType, double discount,
                             int seats, String transmission,int horsepower,String carClass) {
        return new Car(id, brand, model, price, fuelType, discount, seats,transmission,horsepower,carClass);
    }
 }

