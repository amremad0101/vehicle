public class CreditCardPayment implements Payable {
    public CreditCardPayment(){

    }
 @Override
       public boolean processPayment (double amount){
        System.out.println("Processing credit card payment of: " + amount + "$");
            return true;//we can add a validation condtion here 
        }
       
}
