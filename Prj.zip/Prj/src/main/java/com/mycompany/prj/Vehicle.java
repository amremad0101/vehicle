public abstract class Vehicle implements Comparable<Vehicle> {
    protected String id;
    protected String brand;
    protected String model;
    protected double pricePerDay;
    protected boolean isAvailable;
    protected String fuelType;//Electric,Petrol,Hybrid,No fuel
    protected double discount;//0-100%
    
    public Vehicle(String id, String brand, String model, double pricePerDay,String fuelType,double discount) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.isAvailable = true;   // default available
        this.fuelType=fuelType;
        this.discount=discount;
    }
    
    //Abstract method
    public abstract double calculateCost(int days);
    //Getter Functions
    public String getBrand() {return brand;}
       
    public String getModel() {return model;}
        
    public double getPricePerDay() {return pricePerDay;}

    public boolean isIsAvailable() {return isAvailable;}
     
    public String getId() {return id;}

    public String getFuelType() {return fuelType;}

    public double getDiscount() {return discount;}

    //Setter Functions(we can add the rest if needed later)
    public void setAvailable(boolean status) {this.isAvailable = status;}
    
    //Discount depending on vehicle type
    public double getDiscountedPrice() { return pricePerDay * (1 - discount / 100);}
    
    // For sorting by price
    @Override
    public int compareTo(Vehicle other) {return Double.compare(this.pricePerDay, other.pricePerDay);}

    @Override
    public String toString() {
        return "Vehicle{" + "id=" + id + ", brand=" + brand + ", model=" + model + ", pricePerDay=" + pricePerDay + ", isAvailable=" + isAvailable + ", fuelType=" + fuelType + ", discount=" + discount + '}';
    }
        
}
