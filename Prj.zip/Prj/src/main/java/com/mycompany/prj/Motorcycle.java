public class Motorcycle extends Vehicle {
    private int engineCC; // 150cc, 250cc, 600cc etc.
    private double tankCapacity; // in liters
    private double maxLoad; // kg


    public Motorcycle(String id, String brand, String model, double pricePerDay,String fuelType,double discount,double maxLoad,int engineCC,double tankCapacity) {
        super(id, brand, model, pricePerDay,fuelType,discount);
       this.engineCC=engineCC;
       this.tankCapacity=tankCapacity;
       this.maxLoad=maxLoad;
    }

    public int getEngineCC() { return engineCC;}
        
    public double getTankCapacity() {return tankCapacity;}
       

    public double getMaxLoad() {return maxLoad;}
       
    
    @Override
public double calculateCost(int days) {
    double multiplier = 1.0;
    if(engineCC > 500) multiplier += 0.2;
    else multiplier += 0.3;
    return getDiscountedPrice() * days * multiplier;
}


    @Override
public String toString() {
    return "Motorcycle: " + super.toString() +
           " | Engine: " + engineCC + "cc" +
           " | Tank Capacity: " + tankCapacity + "L" +
           " | Max Load: " + maxLoad + "kg";
}

          public static Motorcycle addmotorcycle(String id, String brand, String model, double price,String fuelType,double discount,double maxLoad,int engineCC,double tankCapacity) {
      return new Motorcycle (id, brand, model, price,fuelType,discount,maxLoad,engineCC,tankCapacity); 
}
}
