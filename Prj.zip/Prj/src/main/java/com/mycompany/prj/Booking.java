
public class Booking {
    private Customer customer;
    private Vehicle vehicle;
    private int days;
    private double totalCost;
    private Payable paymentMethod; 

    public Booking( Customer cust, Vehicle veh, int days, Payable method) {
        this.customer = cust;
        this.vehicle = veh;
        this.days = days;
        this.paymentMethod = method;
        
        
        this.totalCost = veh.calculateCost(days); 
    }

    public void confirmBooking() {
        
        boolean isPaid = paymentMethod.processPayment(totalCost);
        
        if (isPaid) {
            System.out.println("Booking Confirmed for User " + customer.getname());
            vehicle.setAvailable(false); 
        } else {
            System.out.println("Booking Failed ");
        }
    }
}