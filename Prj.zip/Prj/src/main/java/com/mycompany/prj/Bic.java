public class Bic extends Vehicle {
    private boolean hasLights;
    private boolean hasBell;
    private double maxLoad;

    public Bic(String id, String brand, String model, double pricePerDay,String fuelType,double discount,double maxLoad) {
        super(id, brand, model, pricePerDay,fuelType,discount);
       this.maxLoad=maxLoad;
       this.hasBell=true;
       this.hasLights=true;
    }

    public boolean isHasLights() {return hasLights;}
        
    public boolean isHasBell() { return hasBell;}
       
    public double getMaxLoad() {return maxLoad;}
    
   public void setBells(boolean status) {this.hasBell = status;}
    
   public void setLights(boolean status) {this.hasLights = status;} 
    
    @Override
    public double calculateCost(int days) { return pricePerDay * days*0.1;}
    
    @Override
public String toString() {
    return "Bicycle: " + super.toString() +
           " | Max Load: " + maxLoad + " kg" +
           " | Lights: " + (hasLights ? "Yes" : "No") +
           " | Bell: " + (hasBell ? "Yes" : "No");
}


       public static Bic addbic(String id, String brand, String model, double price,String fuelType,double discount,double maxLoad) {
      return new Bic (id, brand, model, price,fuelType,discount,maxLoad); 
}

}
